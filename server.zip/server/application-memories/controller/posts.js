import PostMessage from "../models/posts.js"


export const getPosts=async(req,res)=>{
    try{
        const posts=await PostMessage.find();
        return res.status(200).json(posts);
    }
    catch(err){
       return res.status(400).send({message:err.message})
    }
}

export const createPost= async (req,res)=>{
   try{
    const post=req.body;
    const newPost = new PostMessage(post);
    
    await newPost.save();
    return res.status(201).json(newPost)

   }
   catch(err){
       console.log(err)
   }
}

export const updatePost=async(req,res)=>{
    try{

        const {id}=req.params;
        const post=req.body;
        const updatedPost  =await PostMessage.findByIdAndUpdate(id,post,{new:true})
        console.log("updated"+updatedPost)
        return res.status(200).json(updatedPost)
    }
    catch(err){

    }
}

export const deletePost=async(req,res)=>{
    try{
        const {id}=req.params;

    await PostMessage.findByIdAndRemove(id);
    return res.status(200).json({id:id,message:'post deleted Successfully'})
    }
    catch(err){

    }
}

export const likePost=async(req,res)=>{
    try{
        console.log("called")
        const {id}=req.params;
        console.log(id)
        const post=await PostMessage.findById(id);

        const updatedPost=await PostMessage.findByIdAndUpdate(id,{likeCount:post.likeCount+1},{new:true});

        return res.status(200).json(updatedPost)
        console.log(updatedPost)
    }
    catch(err){

    }
    
}